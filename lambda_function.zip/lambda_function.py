import json
from jira import JIRA


def jira_details():
    jira = JIRA(basic_auth=('gautam_karan_singh@hotmail.com', 'Karan@30apr'), options={'server':'https://gautamkaran.atlassian.net'})
    issue = jira.issue('P1-1')
    key= issue.fields.project.key             # 'JRA'
    name=issue.fields.issuetype.name          # 'New Feature'
    displayName = issue.fields.reporter.displayName    # 'Mike Cannon-Brookes [Atlassian]'
    return(key,name,displayName)
    
def lambda_handler(event, context):
    
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event, context)
    elif event['request']['type'] == "IntentRequest":
        return intent_router(event, context)
   
   
def on_launch(event, context):
    key, name, displayName = jira_details()
    out1 = 'Welcome ' + displayName + '. You are now connected to Jira'
    return statement('JIRA Details',out1)

def getIssue(event,context):
    jira = JIRA(basic_auth=('gautam_karan_singh@hotmail.com', 'Karan@30apr'), options={'server':'https://gautamkaran.atlassian.net'})
    issue = jira.issue('P1-1',fields='summary,comment')
    summary = issue.fields.summary
    comments = issue.fields.comment.comments
    a=int(0)
    for i in comments:
        if int(i.id)>a:
            a =int(i.id)
        
    comments=jira.comment(str(issue),a).body
    if summary == []:
        summary = 'No summary for issue ' + str(issue)
    if comments =='':
        comments= ' No comments for issue ' + str(issue)
    
    print(issue,summary,comments)
    out1 = 'Issue number is P1 ' +'. Short Summary of the issue is ' + str(summary) + '. Last comment on issue is ' + str(comments)
    return statement('Issue Details',out1)

	

def getComments(event,context):
    jira = JIRA(basic_auth=('gautam_karan_singh@hotmail.com', 'Karan@30apr'), options={'server':'https://gautamkaran.atlassian.net'})
    issue = jira.issue('P1-1',fields='summary,comment')
    comments = issue.fields.comment.comments
    a=int(0)
    for i in comments:
        if int(i.id)>a:
            a =int(i.id)
        
    comments=jira.comment(str(issue),a).body
    out1 = 'Last comment on Issue P1 is ' + comments
    print(out1)
    return statement('Last Comment',out1)

def getProjectDetails(event,context):
    jira = JIRA(basic_auth=('gautam_karan_singh@hotmail.com', 'Karan@30apr'), options={'server':'https://gautamkaran.atlassian.net'})
    projects = jira.project('P1')
    projectName = projects.name
    leadName=projects.lead.displayName    
    print(projects,projectName,leadName)
    out1 = 'Project id P1 is for '+ projectName +'. And the project is led by Mr. ' + leadName
    return statement('Project Details',out1)


	
def intent_router(event, context):
    intent = event['request']['intent']['name']

    # Custom Intents
    
    if intent == "getComments":
        return getComments(event, context)
    
    if intent == "getProjectDetails":
        return getProjectDetails(event, context)
    
    if intent == "getIssue":
        return getIssue(event, context)
    
    if intent == "AMAZON.CancelIntent":
        return cancel_intent()

    if intent == "AMAZON.HelpIntent":
        return help_intent()

    if intent == "AMAZON.StopIntent":
        return stop_intent()


##############################
# Required Intents
##############################


def cancel_intent():
    return statement("CancelIntent", "You want to cancel")	#don't use CancelIntent as title it causes code reference error during certification 


def help_intent():
    return statement("CancelIntent", "You want help")		#same here don't use CancelIntent


def stop_intent():
    return statement("StopIntent", "You want to stop")		#here also don't use StopIntent

##############################
# Custom Intents
##############################


def statement(title, body):
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)
    speechlet['card'] = build_SimpleCard(title, body)
    speechlet['shouldEndSession'] = True
    return build_response(speechlet)
    
def build_PlainSpeech(body):
    speech = {}
    speech['type'] = 'PlainText'
    speech['text'] = body
    return speech


def build_response(message, session_attributes={}):
    response = {}
    response['version'] = '1.0'
    response['sessionAttributes'] = session_attributes
    response['response'] = message
    return response


def build_SimpleCard(title, body):
    card = {}
    card['type'] = 'Simple'
    card['title'] = title
    card['content'] = body
    return card