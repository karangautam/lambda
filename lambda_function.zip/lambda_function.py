import json
from jira import JIRA


def jira_details():
    jira = JIRA(basic_auth=('karan.gautam1986', 'Karan@30apr'), options={'server':'http://192.168.0.103:8080'})
    issue = jira.issue('PROJ-1')
    key= issue.fields.project.key             # 'JRA'
    name=issue.fields.issuetype.name          # 'New Feature'
    displayName = issue.fields.reporter.displayName    # 'Mike Cannon-Brookes [Atlassian]'
    return(key,name,displayName)
    
def lambda_handler(event, context):
    
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event, context)
    elif event['request']['type'] == "IntentRequest":
        return intent_router(event, context)
   
   
def on_launch(event, context):
    key, name, displayName = jira_details()
    out1 = 'your key is ' + key + 'your name is ' + name + ' your display name is ' + displayName
    return statement(out1)

def intent_router(event, context):
    intent = event['request']['intent']['name']

    # Custom Intents

    if intent == "tellname":
        return tellname(event, context)

    # Required Intents

    if intent == "AMAZON.CancelIntent":
        return cancel_intent()

    if intent == "AMAZON.HelpIntent":
        return help_intent()

    if intent == "AMAZON.StopIntent":
        return stop_intent()


##############################
# Required Intents
##############################


def cancel_intent():
    return statement("CancelIntent", "You want to cancel")	#don't use CancelIntent as title it causes code reference error during certification 


def help_intent():
    return statement("CancelIntent", "You want help")		#same here don't use CancelIntent


def stop_intent():
    return statement("StopIntent", "You want to stop")		#here also don't use StopIntent

##############################
# Custom Intents
##############################

def tellname(event, context):
    name = "My Lord you are Karan Singh Gautam"
    return statement("Karan Singh Gautam", name)




def statement(title, body):
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)
    speechlet['card'] = build_SimpleCard(title, body)
    speechlet['shouldEndSession'] = True
    return build_response(speechlet)
    
def build_PlainSpeech(body):
    speech = {}
    speech['type'] = 'PlainText'
    speech['text'] = body
    return speech


def build_response(message, session_attributes={}):
    response = {}
    response['version'] = '1.0'
    response['sessionAttributes'] = session_attributes
    response['response'] = message
    return response


def build_SimpleCard(title, body):
    card = {}
    card['type'] = 'Simple'
    card['title'] = title
    card['content'] = body
    return card